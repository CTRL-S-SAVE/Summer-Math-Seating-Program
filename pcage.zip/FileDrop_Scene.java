package pcage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;

public class FileDrop_Scene extends Scene {
	Label label = new Label("Please drop in an Excel file");
	boolean fileDropped = false;

	public FileDrop_Scene(BorderPane bp) {
		super(bp,551,400);
		bp.setCenter(label);
		label.setFont(new Font("Arial", 12));
		addEvents();
	}	

	private void addEvents() {
		setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                if (db.hasFiles()) {
                    event.acceptTransferModes(TransferMode.COPY);
                } else {
                    event.consume();
                }
            }
        });
        
        // Dropping over surface
        setOnDragDropped(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasFiles()) {
                    success = true;
                    String filePath = null;
                    for (File file:db.getFiles()) {
                        filePath = file.getAbsolutePath();
                        if(getFileExtension(filePath).equals("xlsx")) {
                        	SheetReader reader = null;
                        	try {
								reader = new SheetReader(filePath);
							} catch (IOException e) {
								e.printStackTrace();
							}
                        	/*label.setText("");
                        	while(reader.hasNext()) {
                        		ArrayList<String> tmp = reader.getNext();
                        		if(tmp.size()>0) {
                        			for(String s: tmp) {
                        				label.setText(label.getText()+s+"\t");
                        			}
                        			label.setText(label.getText()+"\n");
                        		}            			
                        	}     */
                        	fileDropped = true;
                        } else {
                        	label.setText("The file you dropped in was not an Excel file.\nPlease drop in an Excel file.");
                        }
                    }
                }
                event.setDropCompleted(success);
                event.consume();
            }
        });		
	}
	
	private static String getFileExtension(String fileName) {
        //String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
	
	public String getLabelText() {
		return label.getText();
	}
	
	public boolean hasFileDropped() {
		return fileDropped;
	}
}
