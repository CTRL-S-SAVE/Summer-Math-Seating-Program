package pcage;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Program extends Application {
	
	public void start(Stage stage) {
		BorderPane bp = new BorderPane();
		stage.setTitle("Excel Reader");
		Scene scene = new FileDrop_Scene(bp);
		stage.setScene(scene);
		stage.show();
	}
		
	public static void main(String[] args) {
        Application.launch(args);
    }
}
